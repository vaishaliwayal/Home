package com.cjc;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class ServLife implements Servlet {
	

	ServletConfig cfg=null;
	
	private void init() {     ///// this method not call only cl init cofig then service...
		// TODO Auto-generated method stub
		
		System.out.println("init..");

	}
	
	@Override
	public void destroy() {
		
		System.out.println("destroy method");
		
	}

	

	@Override
	public String getServletInfo() {
		
		return null;
	}

	@Override
	public void init(ServletConfig sc) throws ServletException {
		System.out.println("init config method");
		
	}

	private void service() {
		
		System.out.println("hello service...");
		
		destroy();
		
	}



	@Override
	public ServletConfig getServletConfig() {
		
		return cfg;
	}



	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	   System.out.println("hello service...");
		
	}

}

